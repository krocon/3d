
/*
UNIVERSAL SHELLY ENCLOSURE GENERATOR V3.5
MakerWorld/OpenSCAD Parametric Generator

V3.5: adaptive enclosure proportions + model-shaped device cradle + automatic WAGO layout

Mechanical enclosure generator only.
No electrical wiring instructions are generated.
No VDE / CE / IP / fire-safety certification is claimed.

Verified device envelopes included in the library are documented in README.
Unknown/future devices must use Custom Device.
*/

/* [PRESET] */

preset = "Compact_Shelly_Box"; // [Compact_Shelly_Box:Compact Shelly Box, Shelly_WAGO:Shelly + WAGO, Junction_Box:Junction Box, Outdoor_Style:Robust Outdoor-Style, Multi_Device:Multi Device, Socket_Module_Box:Socket Module Box, Custom:Custom]

/* [AUSGABE] */

output_part = "all_parts"; // [base:Gehäuse, lid:Deckel, all_parts:Gehäuse + Deckel, device_fit_test:Gerätehalter-Test, wago_fit_test:WAGO-Test, snap_fit_test:Snap-Fit-Test, insert_fit_test:Heat-Set-Test, cable_fit_test:Kabelöffnung-Test, gland_set:Anbauverschraubung + Gegenmutter]

preview_components = true; // [true:Komponenten anzeigen, false:Nur druckbare Geometrie]
preview_only = false; // [true:Nur Vorschau, false:Normale Ausgabe]

/* [DEVICE] */

device_count = 1; // [1:1:2]

shelly_model = "Shelly_1_Gen4"; // [Shelly_1_Gen4:Shelly 1 Gen4, Shelly_1PM_Gen4:Shelly 1PM Gen4, Shelly_2PM_Gen4:Shelly 2PM Gen4, Shelly_1_Gen3:Shelly 1 Gen3, Shelly_1PM_Gen3:Shelly 1PM Gen3, Shelly_2PM_Gen3:Shelly 2PM Gen3, Shelly_EM_Gen3:Shelly EM Gen3, Shelly_Plus_1:Shelly Plus 1, Shelly_Plus_1PM:Shelly Plus 1PM, Shelly_Plus_2PM:Shelly Plus 2PM, Shelly_Plus_i4:Shelly Plus i4, Shelly_1_Mini_Gen3:Shelly 1 Mini Gen3, Shelly_1PM_Mini_Gen3:Shelly 1PM Mini Gen3, Shelly_PM_Mini_Gen3:Shelly PM Mini Gen3, Shelly_1_Mini_Gen4:Shelly 1 Mini Gen4, Shelly_1PM_Mini_Gen4:Shelly 1PM Mini Gen4, Shelly_EM_Mini_Gen4:Shelly EM Mini Gen4, Shelly_Dimmer_0_1_10V_Gen4:Shelly Dimmer 0/1-10V PM Gen4, Shelly_Plus_RGBW_PM:Shelly Plus RGBW PM, Shelly_Plus_AddOn:Shelly Plus Add-on, Shelly_Plus_Uni:Shelly Plus Uni, Shelly_Uni:Shelly Uni, Custom_Device:Custom Device]

custom_device_width = 42;  // X [15:0.5:100]
custom_device_depth = 37;  // Y [15:0.5:100]
custom_device_height = 16; // Z [8:0.5:45]

device_rotation = 0; // [0:0°, 90:90°]
device_layout = "side_by_side"; // [side_by_side:Nebeneinander, stacked:Übereinander]
device_gap = 8; // [4:1:20]

terminal_side = "front"; // [front:Vorne, back:Hinten, left:Links, right:Rechts]
device_position_x = 0; // [-30:1:30]
device_position_y = 0; // [-30:1:30]

/* [DEVICE HOLDER] */

device_holder = "contour_cradle"; // [contour_cradle:Kontur-Aufnahme, clip_mount:Clip Mount, side_guides:Side Guides, frame:Frame, free_placement:Free Placement]

general_clearance = 0.40; // [0.15:0.05:1.5]
device_clearance = 0.55; // [0.20:0.05:1.5]

holder_wall = 1.8; // [1.2:0.2:3.2]
holder_height = 7; // [3:1:14]
holder_segment = 10; // [6:1:22]
cradle_height = 4.5; // niedrige Konturführung [2.5:0.5:8]
cradle_opening = 16; // Öffnung an Anschlussseite [8:1:30]

clip_lip = 0.65; // [0:0.05:1.3]
clip_lip_height = 1.0; // [0.5:0.1:2.0]
clip_axis = "left_right"; // [left_right:Links/Rechts, front_back:Vorne/Hinten]

device_platform = false; // [true:Mit Ablage, false:Ohne Ablage]
platform_height = 1.0; // [0.4:0.2:3.0]

terminal_wire_space = 10; // [4:1:25]
other_side_space = 3; // [1:1:12]

/* [AUTO SIZE] */

auto_size = true; // [true:Automatisch, false:Manuell]
auto_size_profile = "tight"; // [tight:Kompakt, standard:Standard, service:Mehr Anschlussraum]

manual_inner_width = 90; // [40:1:250]
manual_inner_depth = 70; // [40:1:250]
manual_inner_height = 28; // [18:1:100]

auto_edge_margin = 6; // Mindest-Rand bei Auto Size [4:1:15]
section_gap = 6; // [3:1:15]
extra_inner_width = 0; // [0:1:60]
extra_inner_depth = 0; // [0:1:60]
extra_inner_height = 0; // [0:1:30]

/* [ENCLOSURE] */

wall_thickness = 2.4; // [1.8:0.2:5.0]
bottom_thickness = 2.4; // [1.8:0.2:5.0]
corner_radius = 5; // [2:0.5:12]

robust_wall_min = 3.2; // Outdoor-style Mindestwand [2.6:0.2:5.0]

/* [LID] */

lid_type = "screw"; // [screw:Schraubdeckel, snap_fit:Snap-Fit, sliding:Schiebedeckel]
lid_thickness = 2.4; // [1.8:0.2:5.0]
lid_clearance = 0.30; // [0.15:0.05:0.8]
snap_fit_clearance = 0.25; // [0.10:0.05:0.6]
lid_plug_depth = 2.4; // [1.4:0.2:5.0]

slide_rail_height = 2.4; // [1.5:0.2:4.0]
slide_rail_depth = 2.2; // [1.5:0.2:4.0]

/* [SCREWS & INSERTS] */

screw_system = "M3_heatset"; // [M3_heatset:M3 Heat-Set, self_tapping:Self-Tapping, plain_hole:Normales Durchgangsloch]

screw_boss_diameter = 8; // [6:0.5:12]
screw_diameter = 3.4; // [2.5:0.1:5.0]

insert_diameter = 4.6; // [3.5:0.1:6.5]
insert_depth = 5.0; // [3:0.5:9]
insert_clearance = 0.10; // [0:0.05:0.4]

self_tapping_pilot = 2.5; // [1.8:0.1:3.5]

screw_head_recess = true; // [true:Versenkt, false:Nicht versenkt]
screw_head_diameter = 6.2; // [5:0.2:9]
screw_head_depth = 1.4; // [0.6:0.2:3]

/* [WAGO] */

wago_enabled = true; // [true:WAGO aktiv, false:Ohne WAGO]

wago_type = "221_413"; // [221_412:WAGO 221-412, 221_413:WAGO 221-413, 221_415:WAGO 221-415, Custom_WAGO:Custom WAGO]

wago_count = 2; // [1:1:8]
wago_position = "auto"; // [auto:Automatisch kompakt, left:Links, right:Rechts, front:Vorne, back:Hinten]
wago_orientation = "auto"; // [auto:Automatisch, vertical_list:Untereinander, horizontal_row:Nebeneinander]

wago_clearance = 0.45; // [0.15:0.05:1.5]
wago_holder_wall = 1.5; // [1.0:0.1:3.0]
wago_holder_height = 5; // [3:0.5:10]
wago_gap = 3; // [1:1:10]

custom_wago_width = 18.6; // [8:0.5:50]
custom_wago_depth = 18.3; // [8:0.5:40]
custom_wago_height = 8.15; // [4:0.25:25]

/* [CABLE ENTRIES LEFT] */

left_entry_type = "round"; // [none:Keine, hole:Einfaches Loch, round:Runde Durchführung, gland:Kabelverschraubung, grommet:Flexible Durchführung]
left_entry_count = 1; // [1:1:4]
left_entry_diameter = 12; // [4:1:24]
left_entry_spacing = 16; // [8:1:35]
left_entry_offset = 0; // [-40:1:40]
left_entry_height = 10; // [5:1:30]

/* [CABLE ENTRIES RIGHT] */

right_entry_type = "round"; // [none:Keine, hole:Einfaches Loch, round:Runde Durchführung, gland:Kabelverschraubung, grommet:Flexible Durchführung]
right_entry_count = 1; // [1:1:4]
right_entry_diameter = 12; // [4:1:24]
right_entry_spacing = 16; // [8:1:35]
right_entry_offset = 0; // [-40:1:40]
right_entry_height = 10; // [5:1:30]

/* [CABLE ENTRIES FRONT] */

front_entry_type = "none"; // [none:Keine, hole:Einfaches Loch, round:Runde Durchführung, gland:Kabelverschraubung, grommet:Flexible Durchführung]
front_entry_count = 1; // [1:1:4]
front_entry_diameter = 12; // [4:1:24]
front_entry_spacing = 16; // [8:1:35]
front_entry_offset = 0; // [-40:1:40]
front_entry_height = 10; // [5:1:30]

/* [CABLE ENTRIES BACK] */

back_entry_type = "none"; // [none:Keine, hole:Einfaches Loch, round:Runde Durchführung, gland:Kabelverschraubung, grommet:Flexible Durchführung]
back_entry_count = 1; // [1:1:4]
back_entry_diameter = 12; // [4:1:24]
back_entry_spacing = 16; // [8:1:35]
back_entry_offset = 0; // [-40:1:40]
back_entry_height = 10; // [5:1:30]

/* [CABLE GLAND / GROMMET] */

include_printable_glands = true; // [true:Verschraubung mitdrucken, false:Nur Gehäuseöffnung]

/* Panel thread - goes through enclosure wall */
gland_panel_thread_diameter = 16; // [10:1:32]
gland_panel_thread_pitch = 1.5; // [1.0:0.25:3.0]
gland_panel_thread_length = 8; // [5:1:16]
gland_panel_clearance = 0.40; // [0.15:0.05:0.8]

/* Hex shoulder */
gland_flange_diameter = 24; // [16:1:40]
gland_flange_height = 5; // [3:0.5:8]

/* Upper thread for compression cap */
gland_cap_thread_diameter = 20; // [14:1:36]
gland_cap_thread_pitch = 1.5; // [1.0:0.25:3.0]
gland_cap_thread_length = 7; // [4:1:12]

/* Cable opening */
gland_cable_diameter = 7; // [3:0.5:18]
gland_cable_clearance = 0.40; // [0.15:0.05:1.2]

/* Locknut */
gland_nut_diameter = 24; // [16:1:40]
gland_nut_thickness = 5; // [3:0.5:8]
gland_thread_clearance = 0.30; // [0.15:0.05:0.70]

/* Compression cap */
gland_cap_enabled = true; // [true:Mit Schraubkappe, false:Nur Grundkörper + Mutter]
gland_cap_outer_diameter = 26; // [18:1:42]
gland_cap_grip_height = 5; // [3:0.5:9]
gland_cap_dome_height = 6; // [3:0.5:10]
gland_cap_top_diameter = 18; // [12:1:30]

/* Flexible grommet opening */
grommet_outer_diameter = 18; // [8:1:32]
grommet_lip_depth = 1.5; // [0.6:0.1:3]

cable_clearance = 0.30; // [0.1:0.05:1.0]

/* [CABLE MANAGEMENT] */

cable_management = false; // [true:Aktiv, false:Aus]
cable_channels = false; // [true:Kabelkanäle, false:Keine]
cable_tie_mounts = false; // [true:Kabelbinderhalter, false:Keine]
strain_relief = false; // [true:Zugentlastung, false:Keine]
internal_divider = false; // [true:Trennwand, false:Keine]

channel_width = 8; // [5:1:16]
channel_wall = 1.4; // [1.0:0.2:2.5]
channel_height = 4; // [2:0.5:8]

tie_slot_width = 4; // [2:0.5:7]
tie_slot_length = 10; // [6:1:18]

/* [MOUNTING] */

mounting_type = "none"; // [none:Keine, wall_ears:Montageohren, keyholes:Schlüssellöcher, din_clip:DIN-Clip Vorbereitung, magnets:Magnettaschen, cable_tie:Kabelbinder-Montage]

mount_hole_diameter = 4.2; // [3:0.2:7]
mount_ear_width = 14; // [10:1:24]

magnet_diameter = 10; // [6:1:20]
magnet_depth = 3; // [2:0.5:6]
magnet_clearance = 0.20; // [0.05:0.05:0.6]

din_clip_width = 35; // mechanische DIN-Aufnahme [30:1:45]
din_clip_lip = 2.2; // [1.2:0.2:4]

/* [VENTILATION] */

ventilation = "none"; // [none:Keine, slots:Schlitze, grid:Gitter, honeycomb:Honeycomb]
vent_count = 6; // [3:1:12]
vent_size = 4; // [2:0.5:8]
vent_spacing = 3; // [2:0.5:8]
vent_safe_margin = 12; // Abstand zu Schraubpunkten/Rand [8:1:22]

/* [LABEL] */

label_text = ""; // Optional
label_style = "none"; // [none:Kein Label, engraved:Eingraviert, raised:Erhaben, label_plate:Label-Fläche]
label_size = 8; // [4:1:18]
label_depth = 0.6; // [0.3:0.1:1.5]

/* [SOCKET MODULES - MECHANICAL ONLY] */

socket_count = 0; // [0:1:6]
socket_module_width = 0; // Nutzer muss echtes Modul messen [0:0.5:80]
socket_module_depth = 0; // [0:0.5:80]
socket_module_height = 0; // [0:0.5:60]
socket_clearance = 0.6; // [0.2:0.1:1.5]
socket_gap = 6; // [3:1:15]

/* [QUALITY] */

part_spacing = 20; // [10:1:40]
quality = 72; // [36:Entwurf, 72:Normal, 120:Hoch]

$fn = quality;


/* [Hidden] */

// Internal fixtures intentionally overlap the enclosure floor.
// This prevents coplanar/floating bodies in CGAL/MakerWorld.
ground_overlap = 0.20;
max_entry_diameter = max([
    left_entry_diameter,
    right_entry_diameter,
    front_entry_diameter,
    back_entry_diameter
]);

// ============================================================
// VERIFIED DEVICE LIBRARY
// Each entry returns [width X, depth Y, height Z, terminal side code]
// terminal side: 0 front, 1 back, 2 left, 3 right
// ============================================================

function device_data(name) =
    name == "Shelly_1_Gen4"                ? [42,37,16,0] :
    name == "Shelly_1PM_Gen4"              ? [42,37,16,0] :
    name == "Shelly_2PM_Gen4"              ? [42,37,16,0] :
    name == "Shelly_1_Gen3"                 ? [42,37,16,0] :
    name == "Shelly_1PM_Gen3"               ? [42,37,16,0] :
    name == "Shelly_2PM_Gen3"               ? [42,37,16,0] :
    name == "Shelly_EM_Gen3"                ? [42,37,16,0] :
    name == "Shelly_Plus_1"                 ? [42,37,16,0] :
    name == "Shelly_Plus_1PM"               ? [42,37,16,0] :
    name == "Shelly_Plus_2PM"               ? [42,37,16,0] :
    name == "Shelly_Plus_i4"                ? [42,37,16,0] :
    name == "Shelly_1_Mini_Gen3"            ? [34,29,16,0] :
    name == "Shelly_1PM_Mini_Gen3"          ? [34,29,16,0] :
    name == "Shelly_PM_Mini_Gen3"           ? [34,29,16,0] :
    name == "Shelly_1_Mini_Gen4"            ? [34,29,16,0] :
    name == "Shelly_1PM_Mini_Gen4"          ? [34,29,16,0] :
    name == "Shelly_EM_Mini_Gen4"           ? [34,29,16,0] :
    name == "Shelly_Dimmer_0_1_10V_Gen4"    ? [43.5,38.5,17,0] :
    name == "Shelly_Plus_RGBW_PM"            ? [37,42,12,0] :
    name == "Shelly_Plus_AddOn"              ? [42,37,15,0] :
    name == "Shelly_Plus_Uni"                ? [21,40,7,0] :
    name == "Shelly_Uni"                     ? [20,33,13,0] :
    [custom_device_width,custom_device_depth,custom_device_height,0];

raw_dev = device_data(shelly_model);
raw_dw = raw_dev[0];
raw_dd = raw_dev[1];
raw_dh = raw_dev[2];

dev_w = device_rotation == 90 ? raw_dd : raw_dw;
dev_d = device_rotation == 90 ? raw_dw : raw_dd;
dev_h = raw_dh;

function wago_width(t) =
    t == "221_412" ? 13.0 :
    t == "221_413" ? 18.6 :
    t == "221_415" ? 29.8 :
    custom_wago_width;

function wago_depth(t) =
    t == "221_412" || t == "221_413" || t == "221_415"
    ? 18.3
    : custom_wago_depth;

function wago_height(t) =
    t == "221_412" || t == "221_413" || t == "221_415"
    ? 8.15
    : custom_wago_height;


// ============================================================
// EFFECTIVE PRESET VALUES
// ============================================================

eff_wago_enabled =
    preset == "Compact_Shelly_Box" ? false :
    preset == "Shelly_WAGO" ? true :
    preset == "Junction_Box" ? true :
    wago_enabled;

eff_device_count =
    preset == "Multi_Device" ? max(2,device_count) : device_count;

eff_wall =
    preset == "Outdoor_Style"
    ? max(wall_thickness,robust_wall_min)
    : wall_thickness;

eff_extra_w =
    preset == "Junction_Box"
    ? max(extra_inner_width,25)
    : extra_inner_width;

eff_extra_d =
    preset == "Junction_Box"
    ? max(extra_inner_depth,25)
    : extra_inner_depth;

eff_extra_h =
    preset == "Outdoor_Style"
    ? max(extra_inner_height,5)
    : extra_inner_height;


/*
Auto Size profiles:
TIGHT     = visibly hugs the selected device/holders.
STANDARD  = balanced installation room.
SERVICE   = generous wire/service space.
For screw lids we still reserve enough space for the corner bosses.
*/
profile_margin =
    auto_size_profile == "tight" ? 4 :
    auto_size_profile == "service" ? 12 :
    7;

boss_required_margin =
    lid_type == "screw"
    ? screw_boss_diameter/2 + 1.5
    : 3;

effective_edge_margin =
    max(
        auto_edge_margin,
        profile_margin,
        boss_required_margin
    );

profile_wire_bonus =
    auto_size_profile == "tight" ? 0 :
    auto_size_profile == "service" ? 8 :
    3;


// ============================================================
// DEVICE FOOTPRINT / LAYOUT
// ============================================================

effective_terminal_wire_space = terminal_wire_space + profile_wire_bonus;

term_extra_front = terminal_side == "front" ? effective_terminal_wire_space : 0;
term_extra_back  = terminal_side == "back"  ? effective_terminal_wire_space : 0;
term_extra_left  = terminal_side == "left"  ? effective_terminal_wire_space : 0;
term_extra_right = terminal_side == "right" ? effective_terminal_wire_space : 0;

single_zone_w =
    dev_w + 2*(device_clearance+other_side_space)
    + term_extra_left + term_extra_right;

single_zone_d =
    dev_d + 2*(device_clearance+other_side_space)
    + term_extra_front + term_extra_back;

devices_zone_w =
    eff_device_count == 1 ? single_zone_w :
    device_layout == "side_by_side"
    ? 2*single_zone_w + device_gap
    : single_zone_w;

devices_zone_d =
    eff_device_count == 1 ? single_zone_d :
    device_layout == "stacked"
    ? 2*single_zone_d + device_gap
    : single_zone_d;

socket_valid =
    socket_count == 0 ||
    (
        socket_module_width > 0 &&
        socket_module_depth > 0 &&
        socket_module_height > 0
    );

socket_zone_w =
    socket_count > 0
    ? socket_count*(socket_module_width+2*socket_clearance)
      + (socket_count-1)*socket_gap
    : 0;

socket_zone_d =
    socket_count > 0
    ? socket_module_depth+2*socket_clearance
    : 0;


// ============================================================
// WAGO FOOTPRINT + ADAPTIVE LAYOUT
// ============================================================

ww = wago_width(wago_type)+2*wago_clearance+2*wago_holder_wall;
wd = wago_depth(wago_type)+2*wago_clearance+2*wago_holder_wall;
wh = wago_height(wago_type);

wago_vertical_w = ww;
wago_vertical_d = wago_count*wd+(wago_count-1)*wago_gap;

wago_horizontal_w = wago_count*ww+(wago_count-1)*wago_gap;
wago_horizontal_d = wd;

// Main content before WAGO placement.
main_zone_w = max(devices_zone_w,socket_zone_w);
main_zone_d =
    devices_zone_d
    + (socket_count > 0 ? socket_zone_d+section_gap : 0);

// Candidate layouts. Side placement prefers a vertical list;
// front/back placement prefers a horizontal row.
side_candidate_w = main_zone_w+section_gap+wago_vertical_w;
side_candidate_d = max(main_zone_d,wago_vertical_d);

stack_candidate_w = max(main_zone_w,wago_horizontal_w);
stack_candidate_d = main_zone_d+section_gap+wago_horizontal_d;

// Compact score penalizes both area and excessively long/slender boxes.
function layout_cost(w,d) =
    w*d + 6*abs(w-d) + 2*max(w,d);

side_layout_cost = layout_cost(side_candidate_w,side_candidate_d);
stack_layout_cost = layout_cost(stack_candidate_w,stack_candidate_d);

auto_wago_position =
    side_layout_cost <= stack_layout_cost ? "right" : "back";

effective_wago_position =
    wago_position == "auto"
    ? auto_wago_position
    : wago_position;

effective_wago_orientation =
    wago_orientation != "auto"
    ? wago_orientation
    : (
        effective_wago_position == "left" ||
        effective_wago_position == "right"
        ? "vertical_list"
        : "horizontal_row"
      );

wago_zone_w =
    !eff_wago_enabled ? 0 :
    effective_wago_orientation == "horizontal_row"
    ? wago_horizontal_w
    : wago_vertical_w;

wago_zone_d =
    !eff_wago_enabled ? 0 :
    effective_wago_orientation == "vertical_list"
    ? wago_vertical_d
    : wago_horizontal_d;

content_w =
    !eff_wago_enabled ? main_zone_w :
    (effective_wago_position == "left" || effective_wago_position == "right")
    ? main_zone_w+section_gap+wago_zone_w
    : max(main_zone_w,wago_zone_w);

content_d =
    !eff_wago_enabled ? main_zone_d :
    (effective_wago_position == "front" || effective_wago_position == "back")
    ? main_zone_d+section_gap+wago_zone_d
    : max(main_zone_d,wago_zone_d);

auto_inner_w = content_w+2*effective_edge_margin+eff_extra_w;
auto_inner_d = content_d+2*effective_edge_margin+eff_extra_d;

component_h = max(
    dev_h+(device_platform?platform_height:0)+clip_lip_height,
    eff_wago_enabled ? wh+wago_holder_height : 0,
    socket_count>0 ? socket_module_height : 0
);

auto_inner_h = component_h+5+eff_extra_h;

inner_w = auto_size ? auto_inner_w : manual_inner_width;
inner_d = auto_size ? auto_inner_d : manual_inner_depth;
inner_h = auto_size ? auto_inner_h : manual_inner_height;

outer_w = inner_w+2*eff_wall;
outer_d = inner_d+2*eff_wall;
base_h = bottom_thickness+inner_h;

// ============================================================
// CONTENT CENTERS
// ============================================================

main_cx =
    !eff_wago_enabled ? 0 :
    effective_wago_position == "right" ? -(wago_zone_w+section_gap)/2 :
    effective_wago_position == "left" ?  (wago_zone_w+section_gap)/2 :
    0;

main_cy =
    !eff_wago_enabled ? 0 :
    effective_wago_position == "back" ? -(wago_zone_d+section_gap)/2 :
    effective_wago_position == "front" ? (wago_zone_d+section_gap)/2 :
    0;

wago_cx =
    !eff_wago_enabled ? 0 :
    effective_wago_position == "right" ? (main_zone_w+section_gap)/2 :
    effective_wago_position == "left" ? -(main_zone_w+section_gap)/2 :
    0;

wago_cy =
    !eff_wago_enabled ? 0 :
    effective_wago_position == "back" ? (main_zone_d+section_gap)/2 :
    effective_wago_position == "front" ? -(main_zone_d+section_gap)/2 :
    0;

// ============================================================
// WARNINGS / COLLISION LOGIC
// ============================================================

if (!socket_valid)
    echo("WARNING: Socket modules enabled but dimensions are 0. Measure your real socket module and enter width/depth/height.");

if (!auto_size && manual_inner_width < auto_inner_w)
    echo("WARNING: Manual inner width is smaller than calculated required width.");

if (!auto_size && manual_inner_depth < auto_inner_d)
    echo("WARNING: Manual inner depth is smaller than calculated required depth.");

if (!auto_size && manual_inner_height < auto_inner_h)
    echo("WARNING: Manual inner height is smaller than calculated required height.");

if (eff_wago_enabled && wago_count*max(ww,wd) > max(inner_w,inner_d)*1.8)
    echo("WARNING: WAGO arrangement is very large. Check enclosure dimensions.");

if (lid_type == "sliding" && ventilation == "honeycomb")
    echo("WARNING: Honeycomb + sliding lid may weaken the slide rails. Inspect preview.");

assert(eff_wall >= 1.6,"Wall thickness too small for FDM.");
assert(inner_h > component_h,"Enclosure height insufficient.");
assert(socket_valid,"Socket dimensions must be entered when socket_count > 0.");
echo(
    str(
        "AUTO SIZE RESULT: ",
        outer_w, " x ",
        outer_d, " x ",
        base_h, " mm | Device: ",
        shelly_model,
        " | Device envelope: ",
        dev_w, " x ",
        dev_d, " x ",
        dev_h, " mm | WAGO placement: ",
        effective_wago_position,
        " | WAGO orientation: ",
        effective_wago_orientation
    )
);
assert(gland_panel_thread_diameter > gland_cable_diameter+2,
       "Cable gland panel thread must be larger than cable diameter.");
assert(gland_cap_thread_diameter > gland_cable_diameter+3,
       "Cable gland cap thread must be larger than cable diameter.");
assert(gland_nut_diameter > gland_panel_thread_diameter+2,
       "Cable gland locknut is too small.");



// ============================================================
// GEOMETRY HELPERS
// ============================================================

function safe_r(w,d,r)=max(0.1,min(r,min(w,d)/2-0.1));

module roundedRect2D(w,d,r){
    rr=safe_r(w,d,r);
    hull(){
        for(x=[-w/2+rr,w/2-rr])
            for(y=[-d/2+rr,d/2-rr])
                translate([x,y]) circle(r=rr);
    }
}

module roundedPrism(w,d,h,r){
    linear_extrude(height=h) roundedRect2D(w,d,r);
}

module slot2D(w,h){
    rr=min(w,h)/2;
    hull(){
        translate([-w/2+rr,0]) circle(r=rr);
        translate([w/2-rr,0]) circle(r=rr);
    }
}


// ============================================================
// CABLE ENTRY / GLAND
// ============================================================

module cableEntry(side,type,count,diam,spacing,offset,height){
    if(type!="none"){
        for(i=[0:count-1]){
            shift=(i-(count-1)/2)*spacing+offset;
            if(side=="left" || side=="right"){
                x0=side=="left"?-outer_w/2-0.6:outer_w/2-eff_wall-0.6;
                translate([x0,shift,bottom_thickness+height])
                    rotate([0,90,0])
                        entryShape(type,diam,eff_wall+1.4);
            } else {
                y0=side=="front"?-outer_d/2-0.6:outer_d/2-eff_wall-0.6;
                translate([shift,y0,bottom_thickness+height])
                    rotate([-90,0,0])
                        entryShape(type,diam,eff_wall+1.4);
            }
        }
    }
}

module entryShape(type,diam,length){
    effective_d =
        type=="grommet" ? grommet_outer_diameter :
        type=="gland" ? gland_panel_thread_diameter+2*gland_panel_clearance :
        diam+2*cable_clearance;

    cylinder(h=length,d=effective_d);

    if(type=="grommet")
        translate([0,0,max(0,length-grommet_lip_depth)])
            cylinder(h=grommet_lip_depth+0.2,d=effective_d+2);
}


// ============================================================
// PRINTABLE CABLE GLAND + LOCKNUT + COMPRESSION CAP
// Inspired by the general construction of common panel cable glands.
// Mechanical printed part only - no sealing/IP certification is claimed.
// ============================================================

module externalThread(diameter,pitch,length,depth=undef){
    thread_depth = is_undef(depth) ? max(0.9,pitch*0.42) : depth;
    turns=max(1,length/pitch);
    root_d=max(0.1,diameter-2*thread_depth);
    tooth_half=max(0.2,pitch*0.34);
    slices=max(60,ceil(turns*40));

    union(){
        cylinder(h=length,d=root_d,$fn=max(48,ceil(diameter*3)));

        linear_extrude(
            height=length,
            twist=360*turns,
            slices=slices,
            convexity=16
        )
            translate([root_d/2,0])
                polygon(points=[
                    [0,-tooth_half],
                    [thread_depth,0],
                    [0,tooth_half]
                ]);
    }
}

module internalThreadCutter(diameter,pitch,length,clearance=0.35,depth=undef){
    externalThread(
        diameter+2*clearance,
        pitch,
        length+0.6,
        is_undef(depth) ? max(0.95,pitch*0.42) : depth
    );
}

/*
Cable gland body:
1. lower male thread through enclosure wall
2. hex shoulder like a normal cable gland
3. upper male thread for the compression cap
*/
module cableGlandBody(){
    overlap=0.15;

    difference(){
        union(){
            // Panel mounting thread
            externalThread(
                gland_panel_thread_diameter,
                gland_panel_thread_pitch,
                gland_panel_thread_length
            );

            // Hex shoulder / wrench flange
            translate([
                0,0,
                gland_panel_thread_length-overlap
            ])
                cylinder(
                    h=gland_flange_height+overlap,
                    d=gland_flange_diameter,
                    $fn=6
                );

            // Upper threaded neck
            translate([
                0,0,
                gland_panel_thread_length
                +gland_flange_height
                -2*overlap
            ])
                externalThread(
                    gland_cap_thread_diameter,
                    gland_cap_thread_pitch,
                    gland_cap_thread_length+overlap
                );
        }

        // Cable bore through the full fitting
        translate([0,0,-0.2])
            cylinder(
                h=
                    gland_panel_thread_length
                    +gland_flange_height
                    +gland_cap_thread_length
                    +0.5,
                d=gland_cable_diameter+2*gland_cable_clearance
            );
    }
}

/* Flat hex locknut for the panel thread */
module cableGlandNut(){
    difference(){
        cylinder(
            h=gland_nut_thickness,
            d=gland_nut_diameter,
            $fn=6
        );

        translate([0,0,-0.2])
            internalThreadCutter(
                gland_panel_thread_diameter,
                gland_panel_thread_pitch,
                gland_nut_thickness+0.4,
                gland_thread_clearance
            );
    }
}

/*
Compression cap:
- faceted grip section
- tapered/domed top
- female thread underneath
- central cable opening
*/
module cableGlandCap(){
    if(gland_cap_enabled)
        difference(){
            union(){
                // Grip section
                cylinder(
                    h=gland_cap_grip_height,
                    d=gland_cap_outer_diameter,
                    $fn=12
                );

                // Tapered upper dome
                translate([
                    0,0,
                    gland_cap_grip_height-0.05
                ])
                    cylinder(
                        h=gland_cap_dome_height+0.05,
                        d1=gland_cap_outer_diameter,
                        d2=gland_cap_top_diameter,
                        $fn=48
                    );
            }

            // Female cap thread from underside
            translate([0,0,-0.2])
                internalThreadCutter(
                    gland_cap_thread_diameter,
                    gland_cap_thread_pitch,
                    min(
                        gland_cap_grip_height+1.5,
                        gland_cap_thread_length
                    )+0.4,
                    gland_thread_clearance
                );

            // Cable bore all the way through
            translate([0,0,-0.25])
                cylinder(
                    h=
                        gland_cap_grip_height
                        +gland_cap_dome_height
                        +0.6,
                    d=gland_cable_diameter+2*gland_cable_clearance
                );
        }
}

function glandCountFor(type,count)=
    type=="gland" ? count : 0;

total_gland_count =
    glandCountFor(left_entry_type,left_entry_count)
    + glandCountFor(right_entry_type,right_entry_count)
    + glandCountFor(front_entry_type,front_entry_count)
    + glandCountFor(back_entry_type,back_entry_count);

module singleGlandSet(){
    max_d=max(
        gland_flange_diameter,
        gland_nut_diameter,
        gland_cap_outer_diameter
    );

    spacing=max_d+10;

    // All parts rest directly on the build plate.
    cableGlandBody();

    translate([spacing,0,0])
        cableGlandNut();

    if(gland_cap_enabled)
        translate([2*spacing,0,0])
            cableGlandCap();
}

module allGlandSets(){
    sets=max(1,total_gland_count);
    max_d=max(
        gland_flange_diameter,
        gland_nut_diameter,
        gland_cap_outer_diameter
    );

    row_step=max_d+14;

    for(i=[0:sets-1])
        translate([0,i*row_step,0])
            singleGlandSet();
}


// ============================================================
// ENCLOSURE
// ============================================================

module enclosure(){
    difference(){
        roundedPrism(outer_w,outer_d,base_h,corner_radius);

        translate([0,0,bottom_thickness])
            roundedPrism(
                inner_w,inner_d,inner_h+0.6,
                max(1,corner_radius-eff_wall)
            );

        cableEntry("left",left_entry_type,left_entry_count,left_entry_diameter,left_entry_spacing,left_entry_offset,left_entry_height);
        cableEntry("right",right_entry_type,right_entry_count,right_entry_diameter,right_entry_spacing,right_entry_offset,right_entry_height);
        cableEntry("front",front_entry_type,front_entry_count,front_entry_diameter,front_entry_spacing,front_entry_offset,front_entry_height);
        cableEntry("back",back_entry_type,back_entry_count,back_entry_diameter,back_entry_spacing,back_entry_offset,back_entry_height);

        if(mounting_type=="keyholes") wallMountKeyholes();
        if(mounting_type=="magnets") magnetPockets();
        if(mounting_type=="cable_tie") externalTieSlots();
    }

    if(lid_type=="screw") screwBosses();
    deviceHolder();
    if(eff_wago_enabled) wagoHolder();
    if(socket_count>0) socketMechanicalBays();
    if(cable_management) cableManagement();
    wallMount();
}


// ============================================================
// DEVICE HOLDER
// ============================================================

function dev_center_x(index)=
    main_cx+device_position_x+
    (
        eff_device_count==1 ? 0 :
        device_layout=="side_by_side"
        ? (index==0?-(single_zone_w+device_gap)/2:(single_zone_w+device_gap)/2)
        : 0
    );

function dev_center_y(index)=
    main_cy+device_position_y+
    (
        eff_device_count==1 ? 0 :
        device_layout=="stacked"
        ? (index==0?-(single_zone_d+device_gap)/2:(single_zone_d+device_gap)/2)
        : 0
    );

module deviceHolder(){
    for(index=[0:eff_device_count-1]){
        cx=dev_center_x(index);
        cy=dev_center_y(index);

        if(device_platform)
            translate([cx,cy,bottom_thickness-ground_overlap])
                roundedPrism(
                    dev_w+2*device_clearance,
                    dev_d+2*device_clearance,
                    platform_height+ground_overlap,
                    2
                );

        if(device_holder=="contour_cradle")
            contourCradle(cx,cy);

        if(device_holder=="clip_mount")
            clipMount(cx,cy);

        if(device_holder=="side_guides")
            sideGuides(cx,cy);

        if(device_holder=="frame")
            frameMount(cx,cy);
    }
}

module contourCradle(cx,cy){
    // Low continuous cradle that follows the selected device footprint.
    // The terminal side remains open for wiring.
    z0=bottom_thickness-ground_overlap;
    h=cradle_height+ground_overlap;
    gap=max(4,min(cradle_opening, terminal_side=="front" || terminal_side=="back" ? dev_w*0.65 : dev_d*0.65));

    left_x=cx-dev_w/2-device_clearance-holder_wall;
    right_x=cx+dev_w/2+device_clearance;
    front_y=cy-dev_d/2-device_clearance-holder_wall;
    back_y=cy+dev_d/2+device_clearance;

    // Left rail, split only when terminals are on the left.
    if(terminal_side=="left"){
        seg=(dev_d-gap)/2;
        translate([left_x,cy-dev_d/2-device_clearance,z0])
            cube([holder_wall,max(0.1,seg),h]);
        translate([left_x,cy+gap/2,z0])
            cube([holder_wall,max(0.1,seg),h]);
    } else
        translate([left_x,cy-dev_d/2-device_clearance,z0])
            cube([holder_wall,dev_d+2*device_clearance,h]);

    // Right rail.
    if(terminal_side=="right"){
        seg=(dev_d-gap)/2;
        translate([right_x,cy-dev_d/2-device_clearance,z0])
            cube([holder_wall,max(0.1,seg),h]);
        translate([right_x,cy+gap/2,z0])
            cube([holder_wall,max(0.1,seg),h]);
    } else
        translate([right_x,cy-dev_d/2-device_clearance,z0])
            cube([holder_wall,dev_d+2*device_clearance,h]);

    // Front rail.
    if(terminal_side=="front"){
        seg=(dev_w-gap)/2;
        translate([cx-dev_w/2-device_clearance,front_y,z0])
            cube([max(0.1,seg),holder_wall,h]);
        translate([cx+gap/2,front_y,z0])
            cube([max(0.1,seg),holder_wall,h]);
    } else
        translate([cx-dev_w/2-device_clearance,front_y,z0])
            cube([dev_w+2*device_clearance,holder_wall,h]);

    // Back rail.
    if(terminal_side=="back"){
        seg=(dev_w-gap)/2;
        translate([cx-dev_w/2-device_clearance,back_y,z0])
            cube([max(0.1,seg),holder_wall,h]);
        translate([cx+gap/2,back_y,z0])
            cube([max(0.1,seg),holder_wall,h]);
    } else
        translate([cx-dev_w/2-device_clearance,back_y,z0])
            cube([dev_w+2*device_clearance,holder_wall,h]);
}

module clipMount(cx,cy){
    // All clip walls start inside the enclosure floor.
    // The snap lip is permanently connected to the vertical rail.
    z0=bottom_thickness-ground_overlap;
    platform_extra=device_platform?platform_height:0;
    rail_h=max(
        holder_height+platform_extra+ground_overlap,
        dev_h+platform_extra+clip_lip_height+ground_overlap
    );

    if(clip_axis=="left_right"){
        for(s=[-1,1]){
            inner_x=cx+s*(dev_w/2+device_clearance);
            wall_x=
                s<0
                ? inner_x-holder_wall
                : inner_x;

            translate([
                wall_x,
                cy-holder_segment/2,
                z0
            ])
                cube([
                    holder_wall,
                    holder_segment,
                    rail_h
                ]);

            if(clip_lip>0){
                lip_x=
                    s<0
                    ? inner_x
                    : inner_x-clip_lip;

                translate([
                    lip_x,
                    cy-holder_segment/2,
                    bottom_thickness
                    +platform_extra
                    +dev_h
                    -clip_lip_height
                ])
                    cube([
                        clip_lip,
                        holder_segment,
                        clip_lip_height
                    ]);
            }
        }
    } else {
        for(s=[-1,1]){
            inner_y=cy+s*(dev_d/2+device_clearance);
            wall_y=
                s<0
                ? inner_y-holder_wall
                : inner_y;

            translate([
                cx-holder_segment/2,
                wall_y,
                z0
            ])
                cube([
                    holder_segment,
                    holder_wall,
                    rail_h
                ]);

            if(clip_lip>0){
                lip_y=
                    s<0
                    ? inner_y
                    : inner_y-clip_lip;

                translate([
                    cx-holder_segment/2,
                    lip_y,
                    bottom_thickness
                    +platform_extra
                    +dev_h
                    -clip_lip_height
                ])
                    cube([
                        holder_segment,
                        clip_lip,
                        clip_lip_height
                    ]);
            }
        }
    }
}

module sideGuides(cx,cy){
    z0=bottom_thickness-ground_overlap;
    platform_extra=device_platform?platform_height:0;
    h=min(holder_height,dev_h*0.6)+platform_extra+ground_overlap;

    for(s=[-1,1]){
        inner_x=cx+s*(dev_w/2+device_clearance);
        wall_x=s<0?inner_x-holder_wall:inner_x;

        translate([
            wall_x,
            cy-dev_d/2,
            z0
        ])
            cube([
                holder_wall,
                dev_d,
                h
            ]);
    }
}

module frameMount(cx,cy){
    z0=bottom_thickness-ground_overlap;
    platform_extra=device_platform?platform_height:0;
    fw=dev_w+2*device_clearance;
    fd=dev_d+2*device_clearance;
    difference(){
        translate([cx,cy,z0])
            roundedPrism(fw+2*holder_wall,fd+2*holder_wall,holder_height+platform_extra+ground_overlap,2);
        translate([cx,cy,z0-0.1])
            roundedPrism(fw,fd,holder_height+platform_extra+ground_overlap+0.2,1.5);
    }
}


// ============================================================
// WAGO HOLDER
// ============================================================

module wagoHolder(){
    if(effective_wago_orientation=="vertical_list"){
        total=wago_count*wd+(wago_count-1)*wago_gap;
        for(i=[0:wago_count-1])
            singleWago(
                wago_cx,
                wago_cy-total/2+wd/2+i*(wd+wago_gap)
            );
    } else {
        total=wago_count*ww+(wago_count-1)*wago_gap;
        for(i=[0:wago_count-1])
            singleWago(
                wago_cx-total/2+ww/2+i*(ww+wago_gap),
                wago_cy
            );
    }
}

module singleWago(cx,cy){
    pw=wago_width(wago_type)+2*wago_clearance;
    pd=wago_depth(wago_type)+2*wago_clearance;

    translate([cx,cy,bottom_thickness-ground_overlap])
        roundedPrism(pw,pd,0.8+ground_overlap,1.2);

    for(s=[-1,1])
        translate([
            cx+s*(pw/2+wago_holder_wall/2)-wago_holder_wall/2,
            cy-pd/2-wago_holder_wall,
            bottom_thickness-ground_overlap
        ])
            cube([wago_holder_wall,pd+2*wago_holder_wall,wago_holder_height+ground_overlap]);

    for(s=[-1,1])
        translate([
            cx-pw/2-wago_holder_wall,
            cy+s*(pd/2+wago_holder_wall/2)-wago_holder_wall/2,
            bottom_thickness-ground_overlap
        ])
            cube([pw+2*wago_holder_wall,wago_holder_wall,wago_holder_height+ground_overlap]);
}


// ============================================================
// SOCKET MODULE MECHANICAL BAYS
// ============================================================

module socketMechanicalBays(){
    start_x=main_cx-socket_zone_w/2+(socket_module_width+2*socket_clearance)/2;
    socket_y=main_cy+devices_zone_d/2+section_gap+socket_zone_d/2;

    for(i=[0:socket_count-1]){
        cx=start_x+i*(socket_module_width+2*socket_clearance+socket_gap);
        difference(){
            translate([cx,socket_y,bottom_thickness])
                roundedPrism(
                    socket_module_width+2*socket_clearance+2*holder_wall,
                    socket_module_depth+2*socket_clearance+2*holder_wall,
                    min(holder_height,socket_module_height),
                    2
                );
            translate([cx,socket_y,bottom_thickness-0.1])
                roundedPrism(
                    socket_module_width+2*socket_clearance,
                    socket_module_depth+2*socket_clearance,
                    min(holder_height,socket_module_height)+0.2,
                    1.5
                );
        }
    }
}


// ============================================================
// SCREW BOSSES / HEAT INSERTS
// ============================================================

post_x=inner_w/2-effective_edge_margin/2;
post_y=inner_d/2-effective_edge_margin/2;

module screwBosses(){
    for(x=[-post_x,post_x])
        for(y=[-post_y,post_y])
            screwBoss(x,y);
}

module screwBoss(x,y){
    bh=inner_h-0.7;
    difference(){
        translate([x,y,bottom_thickness-ground_overlap])
            cylinder(h=bh+ground_overlap,d=screw_boss_diameter);

        if(screw_system=="M3_heatset"){
            translate([x,y,bottom_thickness+1])
                cylinder(
                    h=max(0.2,bh-insert_depth),
                    d=self_tapping_pilot
                );
            translate([
                x,y,bottom_thickness+bh-insert_depth
            ])
                heatInsert();
        }

        if(screw_system=="self_tapping")
            translate([x,y,bottom_thickness+1])
                cylinder(h=bh,d=self_tapping_pilot);

        if(screw_system=="plain_hole")
            translate([x,y,bottom_thickness-0.1])
                cylinder(h=bh+0.2,d=screw_diameter);
    }
}

module heatInsert(){
    cylinder(
        h=insert_depth+0.2,
        d=insert_diameter+2*insert_clearance
    );
}


// ============================================================
// CABLE MANAGEMENT
// ============================================================

module cableManagement(){
    if(cable_channels) cableChannels();
    if(cable_tie_mounts) cableTieMounts();
    if(strain_relief) strainRelief();
    if(internal_divider) internalDivider();
}

module cableChannels(){
    // V3.1: short edge guides only.
    // No full-length rails through the usable electronics area.
    z=bottom_thickness-ground_overlap;
    guide_len=min(22,max(12,inner_w*0.18));
    y_front=-inner_d/2+effective_edge_margin/2;
    y_back=inner_d/2-effective_edge_margin/2;

    for(y=[y_front,y_back])
        for(x=[-inner_w*0.27,inner_w*0.27])
            translate([
                x-guide_len/2,
                y-channel_width/2,
                z
            ]){
                cube([guide_len,channel_wall,channel_height]);
                translate([0,channel_width-channel_wall,0])
                    cube([guide_len,channel_wall,channel_height]);
            }
}

module cableTieMounts(){
    for(x=[-inner_w*0.28,inner_w*0.28])
        translate([x,0,bottom_thickness]){
            difference(){
                roundedPrism(
                    tie_slot_length+6,
                    tie_slot_width+6,
                    2.8,
                    2
                );
                translate([0,0,-0.1])
                    linear_extrude(height=3.1)
                        slot2D(tie_slot_length,tie_slot_width);
            }
        }
}

module strainRelief(){
    // generic internal bridge near front cable side
    translate([
        0,
        -inner_d/2+effective_edge_margin/2,
        bottom_thickness-ground_overlap
    ])
        difference(){
            roundedPrism(24,8,5+ground_overlap,2);
            translate([0,0,1.5])
                rotate([90,0,0])
                    cylinder(h=10,d=max(4,max_entry_diameter+1),center=true);
        }
}

module internalDivider(){
    translate([
        0,
        0,
        bottom_thickness
    ])
        cube([1.8,inner_d-2*effective_edge_margin,min(inner_h*0.55,18)]);
}


// ============================================================
// MOUNTING
// ============================================================

module wallMount(){
    if(mounting_type=="wall_ears"){
        for(s=[-1,1]) mountingEar(s);
    }

    if(mounting_type=="din_clip")
        dinMountPreparation();
}

module mountingEar(side){
    ex=side*(outer_w/2+mount_ear_width/2-2);
    difference(){
        hull(){
            translate([side*(outer_w/2-2),0,0])
                cylinder(h=bottom_thickness,d=mount_ear_width);
            translate([ex,0,0])
                cylinder(h=bottom_thickness,d=mount_ear_width);
        }
        translate([ex,0,-0.1])
            cylinder(h=bottom_thickness+0.2,d=mount_hole_diameter);
    }
}

module wallMountKeyholes(){
    for(x=[-inner_w*0.28,inner_w*0.28])
        translate([x,0,-0.1])
            linear_extrude(height=bottom_thickness+0.2)
                union(){
                    circle(d=8);
                    translate([0,5])
                        square([4.2,10],center=true);
                }
}

module dinMountPreparation(){
    // mechanical clip rails only; no certification claim
    translate([
        0,
        outer_d/2-1,
        bottom_thickness
    ]){
        cube([din_clip_width,2.4,5],center=true);
        translate([0,-din_clip_lip,2.2])
            cube([din_clip_width,4.4,1.8],center=true);
    }
}

module magnetPockets(){
    for(x=[-inner_w*0.28,inner_w*0.28])
        translate([x,0,-0.1])
            cylinder(
                h=min(bottom_thickness-0.4,magnet_depth+magnet_clearance),
                d=magnet_diameter+2*magnet_clearance
            );
}

module externalTieSlots(){
    for(x=[-inner_w*0.28,inner_w*0.28])
        translate([x,0,-0.1])
            linear_extrude(height=bottom_thickness+0.2)
                slot2D(12,4);
}


// ============================================================
// LID GENERATOR
// ============================================================

module lid(){
    if(lid_type=="screw") screwLid();
    if(lid_type=="snap_fit") snapLid();
    if(lid_type=="sliding") slidingLid();
}

module lidBasePlate(){
    linear_extrude(height=lid_thickness)
        roundedRect2D(outer_w,outer_d,corner_radius);
}

module lidInnerRing(clearance_value=lid_clearance){
    pw=inner_w-2*clearance_value;
    pd=inner_d-2*clearance_value;
    ring=1.6;

    translate([0,0,lid_thickness-0.01])
        linear_extrude(height=lid_plug_depth)
            difference(){
                roundedRect2D(pw,pd,max(1,corner_radius-eff_wall));
                offset(delta=-ring)
                    roundedRect2D(pw,pd,max(1,corner_radius-eff_wall));
            }
}

module screwLid(){
    difference(){
        union(){
            lidBasePlate();
            lidInnerRing(lid_clearance);
            lidLabelPositive();
        }

        for(x=[-post_x,post_x])
            for(y=[-post_y,post_y]){
                translate([x,y,-0.1])
                    cylinder(
                        h=lid_thickness+lid_plug_depth+0.3,
                        d=screw_diameter
                    );

                if(screw_head_recess)
                    translate([x,y,lid_thickness-screw_head_depth])
                        cylinder(
                            h=screw_head_depth+lid_plug_depth+0.3,
                            d=screw_head_diameter
                        );
            }

        ventilation();
        lidLabelNegative();
    }
}

module snapLid(){
    tab_w=10;
    tab_h=1.2;

    difference(){
        union(){
            lidBasePlate();
            lidInnerRing(snap_fit_clearance);
            for(x=[-inner_w*0.28,inner_w*0.28])
                for(y=[-inner_d/2+1.0,inner_d/2-1.0])
                    translate([
                        x-tab_w/2,
                        y-(y<0?0.8:0),
                        lid_thickness+lid_plug_depth-tab_h
                    ])
                        cube([tab_w,1.6+clip_lip,tab_h]);
            lidLabelPositive();
        }
        ventilation();
        lidLabelNegative();
    }
}

module slidingLid(){
    // flat plate with side rails; enclosure receives matching grooves
    difference(){
        union(){
            translate([0,0,0])
                linear_extrude(height=lid_thickness)
                    roundedRect2D(
                        outer_w-2*lid_clearance,
                        outer_d-2*lid_clearance,
                        max(1,corner_radius-1)
                    );

            for(y=[-inner_d/2+slide_rail_depth/2,inner_d/2-slide_rail_depth/2])
                translate([
                    -inner_w/2,
                    y-slide_rail_depth/2,
                    lid_thickness-0.01
                ])
                    cube([inner_w,slide_rail_depth,slide_rail_height]);

            lidLabelPositive();
        }

        ventilation();
        lidLabelNegative();
    }
}

module lidLabel2D(){
    if(len(label_text)>0)
        text(
            label_text,
            size=label_size,
            halign="center",
            valign="center",
            font="Liberation Sans:style=Bold"
        );
}

module lidLabelPositive(){
    if(label_style=="raised" && len(label_text)>0)
        translate([0,0,lid_thickness-0.01])
            linear_extrude(height=label_depth+0.01)
                lidLabel2D();

    if(label_style=="label_plate" && len(label_text)>0)
        translate([0,0,lid_thickness-0.01])
            roundedPrism(
                min(outer_w*0.55,max(30,len(label_text)*label_size*0.65)),
                label_size+8,
                0.8,
                3
            );
}

module lidLabelNegative(){
    if(label_style=="engraved" && len(label_text)>0)
        translate([0,0,lid_thickness-label_depth])
            linear_extrude(height=label_depth+0.2)
                lidLabel2D();
}


// ============================================================
// VENTILATION
// Positioned centrally inside a safe region away from screw bosses.
// ============================================================

module ventilation(){
    safe_w=max(10,outer_w-2*vent_safe_margin);
    safe_d=max(10,outer_d-2*vent_safe_margin);

    if(ventilation=="slots"){
        for(i=[0:vent_count-1]){
            x=(i-(vent_count-1)/2)*(vent_size+vent_spacing);
            if(abs(x)<safe_w/2)
                translate([x,0,-0.1])
                    linear_extrude(height=lid_thickness+lid_plug_depth+0.3)
                        slot2D(vent_size,min(safe_d*0.7,28));
        }
    }

    if(ventilation=="grid"){
        n=ceil(sqrt(vent_count));
        for(ix=[0:n-1])
            for(iy=[0:n-1]){
                x=(ix-(n-1)/2)*(vent_size+vent_spacing);
                y=(iy-(n-1)/2)*(vent_size+vent_spacing);
                if(abs(x)<safe_w/2 && abs(y)<safe_d/2)
                    translate([x,y,-0.1])
                        cylinder(h=lid_thickness+lid_plug_depth+0.3,d=vent_size);
            }
    }

    if(ventilation=="honeycomb"){
        n=ceil(sqrt(vent_count*1.5));
        for(ix=[-n:n])
            for(iy=[-n:n]){
                x=ix*(vent_size+vent_spacing)*0.87;
                y=iy*(vent_size+vent_spacing)+(abs(ix)%2)*(vent_size+vent_spacing)/2;
                if(abs(x)<safe_w/2 && abs(y)<safe_d/2)
                    translate([x,y,-0.1])
                        linear_extrude(height=lid_thickness+lid_plug_depth+0.3)
                            circle(d=vent_size,$fn=6);
            }
    }
}


// ============================================================
// PREVIEW COMPONENTS
// ============================================================

module previewComponents(){
    if(preview_components){
        for(i=[0:eff_device_count-1]){
            %color([0.05,0.25,0.9,0.45])
                translate([
                    dev_center_x(i)-dev_w/2,
                    dev_center_y(i)-dev_d/2,
                    bottom_thickness+(device_platform?platform_height:0)
                ])
                    cube([dev_w,dev_d,dev_h]);
        }

        if(eff_wago_enabled){
            if(effective_wago_orientation=="vertical_list"){
                total=wago_count*wd+(wago_count-1)*wago_gap;
                for(i=[0:wago_count-1])
                    %color([1,0.4,0,0.45])
                        translate([
                            wago_cx-wago_width(wago_type)/2,
                            wago_cy-total/2+wd/2+i*(wd+wago_gap)-wago_depth(wago_type)/2,
                            bottom_thickness+0.8
                        ])
                            cube([
                                wago_width(wago_type),
                                wago_depth(wago_type),
                                wago_height(wago_type)
                            ]);
            } else {
                total=wago_count*ww+(wago_count-1)*wago_gap;
                for(i=[0:wago_count-1])
                    %color([1,0.4,0,0.45])
                        translate([
                            wago_cx-total/2+ww/2+i*(ww+wago_gap)-wago_width(wago_type)/2,
                            wago_cy-wago_depth(wago_type)/2,
                            bottom_thickness+0.8
                        ])
                            cube([
                                wago_width(wago_type),
                                wago_depth(wago_type),
                                wago_height(wago_type)
                            ]);
            }
        }

        if(screw_system=="M3_heatset" && lid_type=="screw")
            for(x=[-post_x,post_x])
                for(y=[-post_y,post_y])
                    %color([0.8,0.55,0.1,0.6])
                        translate([
                            x,y,
                            base_h-insert_depth-0.7
                        ])
                            cylinder(
                                h=insert_depth,
                                d=insert_diameter
                            );
    }
}


// ============================================================
// FIT TEST MODES
// ============================================================

module deviceFitTest(){
    test_w=dev_w+2*device_clearance+2*holder_wall+10;
    test_d=dev_d+2*device_clearance+2*holder_wall+10;

    roundedPrism(test_w,test_d,2.2,3);

    // local centered version
    if(device_platform)
        translate([0,0,2.2])
            roundedPrism(
                dev_w+2*device_clearance,
                dev_d+2*device_clearance,
                platform_height,
                2
            );

    if(device_holder=="contour_cradle"){
        // simplified contour fit-test
        z0=2.2;
        translate([-dev_w/2-device_clearance-holder_wall,-dev_d/2-device_clearance,z0])
            cube([holder_wall,dev_d+2*device_clearance,cradle_height]);
        translate([dev_w/2+device_clearance,-dev_d/2-device_clearance,z0])
            cube([holder_wall,dev_d+2*device_clearance,cradle_height]);
        translate([-dev_w/2-device_clearance,-dev_d/2-device_clearance-holder_wall,z0])
            cube([dev_w+2*device_clearance,holder_wall,cradle_height]);
        translate([-dev_w/2-device_clearance,dev_d/2+device_clearance,z0])
            cube([dev_w+2*device_clearance,holder_wall,cradle_height]);
    }

    if(device_holder=="clip_mount"){
        z0=2.2+(device_platform?platform_height:0);
        h=min(holder_height,dev_h+clip_lip_height);
        for(s=[-1,1]){
            x=s*(dev_w/2+device_clearance+holder_wall/2);
            translate([x-holder_wall/2,-holder_segment/2,z0])
                cube([holder_wall,holder_segment,h]);
        }
    }
}

module wagoFitTest(){
    pw=wago_width(wago_type)+2*wago_clearance;
    pd=wago_depth(wago_type)+2*wago_clearance;
    roundedPrism(pw+12,pd+12,2.2,3);
    translate([0,0,2.2-bottom_thickness])
        singleWago(0,0);
}

module snapFitTest(){
    base_w=45;
    base_d=24;

    roundedPrism(base_w,base_d,4,3);

    translate([0,0,4])
        difference(){
            roundedPrism(base_w-6,base_d-6,8,2);
            translate([0,0,-0.1])
                roundedPrism(
                    base_w-10-2*snap_fit_clearance,
                    base_d-10-2*snap_fit_clearance,
                    8.2,
                    1.5
                );
        }
}

module insertFitTest(){
    roundedPrism(35,22,8,3);

    for(i=[-1,0,1]){
        d=insert_diameter+2*insert_clearance+i*0.15;
        translate([i*10,0,8-insert_depth])
            cylinder(h=insert_depth+0.2,d=d);
    }
}

module cableFitTest(){
    roundedPrism(60,25,5,3);

    for(i=[-1,0,1]){
        d=max_entry_diameter+i*0.5;
        translate([i*18,0,-0.1])
            cylinder(h=5.2,d=d);
    }
}


// ============================================================
// OUTPUT
// ============================================================

module printOutput(){
    if(output_part=="base")
        enclosure();

    if(output_part=="lid")
        lid();

    if(output_part=="all_parts"){
        enclosure();

        translate([
            outer_w+mount_ear_width+part_spacing,
            0,0
        ]) lid();

        if(include_printable_glands && total_gland_count>0)
            translate([
                0,
                outer_d
                + max([gland_flange_diameter,gland_nut_diameter,gland_cap_outer_diameter])
                + part_spacing,
                0
            ])
                allGlandSets();
    }

    if(output_part=="gland_set")
        allGlandSets();

    if(output_part=="device_fit_test")
        deviceFitTest();

    if(output_part=="wago_fit_test")
        wagoFitTest();

    if(output_part=="snap_fit_test")
        snapFitTest();

    if(output_part=="insert_fit_test")
        insertFitTest();

    if(output_part=="cable_fit_test")
        cableFitTest();
}

if(!preview_only) printOutput();
previewComponents();
